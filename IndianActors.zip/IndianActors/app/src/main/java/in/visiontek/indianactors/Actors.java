package in.visiontek.indianactors;

import android.widget.Spinner;

import java.io.Serializable;

public class Actors implements Serializable {
    String actorName, actorIndustry;
    Integer image;
    Spinner actName,actIndustry;
    public Actors(String actorName, String actorIndustry) {
        this.actorName = actorName;
        this.actorIndustry = actorIndustry;
        this.image = image;
    }

    public Actors() {
    }

    public Actors(Spinner actorName, Spinner actorIndustry) {
        this.actName=actorName;
        this.actIndustry=actorIndustry;
    }

    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    public String getActorIndustry() {
        return actorIndustry;
    }

    public void setActorIndustry(String actorIndustry) {
        this.actorIndustry = actorIndustry;
    }

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }
}
