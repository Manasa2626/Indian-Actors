package in.visiontek.indianactors;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ArrayList<Actors> actorsArrayList;
    TextView addActor;
    Spinner actorName, actorIndustry;
String actVal,actIndV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        actorsArrayList=new ArrayList<>();

        ActorsAdapter actorsAdapter=new ActorsAdapter(this,actorsArrayList);
        recyclerView.setAdapter(actorsAdapter);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Actors");
        loadData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.add:
                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.dialog);
                TextView addActor = dialog.findViewById(R.id.text_id);
                actorName = dialog.findViewById(R.id.spinner);
                actorIndustry = dialog.findViewById(R.id.industry_spinner);
                Button addBtn = dialog.findViewById(R.id.add_btn);
                dialog.show();
                ArrayAdapter<CharSequence> actorsNameAdapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Actors_array, android.R.layout.simple_spinner_dropdown_item);
                actorName.setAdapter(actorsNameAdapter);
                ArrayAdapter<CharSequence> actorIndAdapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.Industry_array, android.R.layout.simple_spinner_dropdown_item);
                actorIndustry.setAdapter(actorIndAdapter);
                actorName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                       actVal=actorName.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                actorIndustry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        actIndV=actorIndustry.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                addBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        addDataToFirebase(actVal,actIndV);
                        dialog.dismiss();
                        loadData();

                       /* Intent in=new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(in);*/
                    }



                    private void addDataToFirebase(String actVal, String actIndV) {
                        Actors actors=new Actors(actVal,actIndV);
                        databaseReference.push().setValue(actors);
                    }


                });
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    private void loadData() {
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    actorsArrayList=new ArrayList<>();
                    for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                        Actors actors=dataSnapshot.getValue(Actors.class);
                        actorsArrayList.add(actors);
                    }
                    ActorsAdapter actorsAdapter=new ActorsAdapter(getApplicationContext(),actorsArrayList);
                    recyclerView.setAdapter(actorsAdapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

    }
}
