package in.visiontek.indianactors;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ActorsAdapter extends RecyclerView.Adapter<ActorsAdapter.MyViewHolder> {
    Context context;
    ArrayList<Actors> actorsArrayList;
    int currentPosition;
    DatabaseReference databaseReference;
    public ActorsAdapter(Context context, ArrayList<Actors> actorsArrayList) {
        this.context=context;
        this.actorsArrayList=actorsArrayList;
    }


    @NonNull
    @Override
    public ActorsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.card_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ActorsAdapter.MyViewHolder holder, int position) {
        Actors actors=actorsArrayList.get(position);
        holder.name.setText(actors.getActorName());
        holder.industry.setText(actors.getActorIndustry());
        if(actors.getActorIndustry().equals("Tollywood")){
            holder.image.setImageResource(R.drawable.tollywood);
        }
        if(actors.getActorIndustry().equals("Bollywood")){
            holder.image.setImageResource(R.drawable.bollywood1);
        }
        if(actors.getActorIndustry().equals("Kollywood")){
            holder.image.setImageResource(R.drawable.kollywood1);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PopupMenu popupMenu = new PopupMenu(context, v);
                currentPosition = holder.getAdapterPosition();
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if(item.getItemId()==R.id.update_id){
                            updateActor();


                            }
                        else if(item.getItemId()==R.id.delete_id){
                            deleteActor();
                        }
                        return true;
                    }

                    private void deleteActor() {
                        Actors actors1=actorsArrayList.get(currentPosition);
                        databaseReference=FirebaseDatabase.getInstance().getReference("Actors");
                        Query query1=databaseReference.orderByChild("actorName").equalTo(actors1.getActorName());
                        query1.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                                    dataSnapshot.getRef().removeValue();
                                    notifyDataSetChanged();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }

                    private void updateActor() {
                        Dialog dialog=new Dialog(context);
                        dialog.setContentView(R.layout.update_actor);
                        dialog.show();
                        EditText nameEdit=dialog.findViewById(R.id.name_update);
                        EditText industryEdit=dialog.findViewById(R.id.industry_update);
                        Button updateBtn=dialog.findViewById(R.id.update_btn);
                        nameEdit.setText(actorsArrayList.get(currentPosition).getActorName());
                        industryEdit.setText(actorsArrayList.get(currentPosition).getActorIndustry());
                        updateBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String upName=nameEdit.getText().toString();
                                String upInd=industryEdit.getText().toString();
                                Actors actors=actorsArrayList.get(currentPosition);
                                actors.setActorName(upName);
                                actors.setActorIndustry(upInd);
                            }
                        });


                    }
                });
                popupMenu.show();
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(context,Final.class);
                in.putExtra("position",actors);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });
    }

    @Override
    public int getItemCount() {
        return actorsArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name,industry;
        ImageView image;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            industry=itemView.findViewById(R.id.industry);
            image=itemView.findViewById(R.id.img);

        }
    }
}
