package in.visiontek.indianactors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Final extends AppCompatActivity {
TextView text,text1;
ImageView image1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        text=findViewById(R.id.name_txt);
        text1=findViewById(R.id.industry_txt);
        image1=findViewById(R.id.img);
        Intent in=getIntent();
        Actors actors=(Actors) in.getSerializableExtra("position");
        text.setText(actors.getActorName());
        text1.setText(actors.getActorIndustry());
        if(actors.getActorIndustry().equals("Tollywood")){
            image1.setImageResource(R.drawable.tollywood);
        }
        if(actors.getActorIndustry().equals("Bollywood")){
            image1.setImageResource(R.drawable.bollywood1);
        }
        if(actors.getActorIndustry().equals("Kollywood")){
           image1.setImageResource(R.drawable.kollywood1);
        }

    }
}